package com.springmdb.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.springmdb.dto.TestDomain;

@Repository
public interface TestRepository extends MongoRepository<TestDomain,Long>{
	TestDomain findById(long id);
}
