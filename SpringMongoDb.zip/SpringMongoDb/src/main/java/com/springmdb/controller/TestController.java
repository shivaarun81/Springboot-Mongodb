package com.springmdb.controller;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springmdb.dto.TestDomain;
import com.springmdb.repository.TestRepository;

@RestController
@RequestMapping("test")
public class TestController {

	@Autowired
	private TestRepository testRepository;
	
	@PostMapping("/add")
	public ResponseEntity save(HttpServletRequest request,@RequestBody TestDomain data)
	{
		System.out.println("ADD Controller");
		testRepository.save(data);
		System.out.println("Data Saved---->"+data.getId());
		return ResponseEntity.ok("success");
	}

	@GetMapping("/getall")
	public ResponseEntity getall() {
		List<TestDomain> testall = testRepository.findAll();
		for(TestDomain s : testall )
		{
			System.out.println(s.getId() +"--"+s.getName());
		}
		return ResponseEntity.ok("success");
	}
	
	@GetMapping("/getbyid/{id}")
	public ResponseEntity getById(@PathVariable long id)
	{
		TestDomain test = testRepository.findById(id);

		System.out.println(test.getId() +"--->"+test.getName());	
		return ResponseEntity.ok("success");
	}
	@DeleteMapping("/delete/{id}")
	public ResponseEntity deleteById(@PathVariable long id)
	{
		testRepository.deleteById(id);
		return ResponseEntity.ok("success");
	}
}
